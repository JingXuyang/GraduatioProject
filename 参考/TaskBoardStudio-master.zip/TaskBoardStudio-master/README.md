# TaskBoardStudio
任务看板，使用Python3+Pyqt5。

![](ReadMeImg/kanban_main.png)

![](ReadMeImg/add_task.png)

![](ReadMeImg/edit_tags.png)


#todo:

任务提醒