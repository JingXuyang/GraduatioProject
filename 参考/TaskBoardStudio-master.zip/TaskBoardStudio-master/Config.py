# -*- coding:utf-8 -*-
__author__ = "liaokong"
__time__ = "2018/10/25 11:50"

import os

tags_config_path = "%s/data/TagsConfig.json" % os.getcwd().replace("\\", "/")
db_path = "%s/data/TasksData.db" % os.getcwd().replace("\\", "/")
ini_path = "%s/data/Config.ini" % os.getcwd().replace("\\", "/")
