# QFlat
Flat style for pyqt

##ExampleButton：

![Image text](ReadMeImg/ExampleButton.png)

##ExampleWidget：

![Image text](ReadMeImg/ExampleWidget.png)

##MessageWidget：

message：

![Image text](ReadMeImg/message_info.png)
![Image text](ReadMeImg/message_success.png)
![Image text](ReadMeImg/message_warning.png)
![Image text](ReadMeImg/message_error.png)

message_ask：

![Image text](ReadMeImg/message_ask_info.png)
![Image text](ReadMeImg/message_ask_warning.png)

